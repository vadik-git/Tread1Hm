﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Thread_HM_02._20
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// 
    

    public partial class MainWindow : Window
    {
        ObservableCollection<int> objCollT1 = new ObservableCollection<int>();
        ObservableCollection<int> objCollT2 = new ObservableCollection<int>();
        Random rnd = new Random();
        Thread[] threadsT2 = new Thread[2];
        Thread[] threads = new Thread[3];

        public void Task1(object obj)
        {

            Tuple<int, int> myTyple = (Tuple<int, int>)obj;


            int value = rnd.Next(myTyple.Item1, myTyple.Item2);

            for (int i = 0 ; i < 10; ++i)
            {
                Application.Current.Dispatcher.Invoke(new Action(() =>
                {
                    i = value;
                    objCollT1.Add(i);

                }));
                Thread.Sleep(1000);
                
            }
        }

        public void Task2()
        {
            int n1 = 1;
            int n2 = 1;



            for(int i = 0; i < 10; ++i)
            {

                Application.Current.Dispatcher.Invoke(new Action(() =>
                {
                   

                 int fib_sum = n1 + n2;
                 n1 = n2;
                 n2 = fib_sum;
                 objCollT2.Add(n2);

                }));
                Thread.Sleep(1000);

            }
        }
       
        public MainWindow()
        {
            InitializeComponent();

            //listBox.ItemsSource = objCollT2;

        }
        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                listBox.ItemsSource = objCollT1;


                int a1 = Convert.ToInt32(tb1.Text);
                int a2 = Convert.ToInt32(tb2.Text);


                for (int i = 0; i < threads.Length; ++i)
                {
                    threads[i] = new Thread(() =>
                    {

                        for (int j = 0; j < 5; j++)
                        {
                            Task1(new Tuple<int, int>(a1, a2));

                        }


                    });
                    threads[i].Start();
                }
                tb1.Text = "";
                tb2.Text = "";
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Diapazon Null {ex.Message}");
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
              listBox2.ItemsSource = objCollT2;
             for (int i = 0; i < threadsT2.Length; ++i)
             {
                 threadsT2[i] = new Thread(() =>
                 {

                     for (int j = 0; j < 1; j++)
                     {
                         Task2();
                     }

                 });
                 threadsT2[i].Start();
             }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < threadsT2.Length; ++i)
            {

                threadsT2[i].Resume();

            }


            
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < threadsT2.Length; ++i)
            {

                threadsT2[i].Suspend();
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < threadsT2.Length; ++i)
            {

                threadsT2[i].Abort();


            }         }
        }
}
